<template>
  <van-sticky>
    <van-nav-bar :title="title"/>
    <van-notice-bar
        left-icon="volume-o"
        mode="closeable"
        scrollable
        text="[公告] 目前正常使用"
    />
  </van-sticky>
</template>

<script lang="ts">
import {useRoute} from 'vue-router'
export default {
  name: "gbobalHeader",
  setup(){
    const route = useRoute();
    const title = route.meta.title ?? "自动化上班"
    return {
      title
    }
  }
}
</script>

<style scoped>

</style>

<script setup lang="ts">

import GbobalHeader from "./components/gbobalHeader.vue";
</script>

<template>
  <van-config-provider theme="dark">
    <gbobal-header></gbobal-header>
    <router-view/>
  </van-config-provider>
</template>

<style>
body{
  background-color: #F7F8FA;
}
</style>

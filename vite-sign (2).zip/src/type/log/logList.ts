export interface logList {
    id:number,
    userId:number,
    msg:string,
    type:number
}

export interface userInfo {
    id: number,
    hcmPhone: number,
    name: string,
    cookie: string,
    autoUp: boolean,
    autoDown: boolean,
    createTime: string,
    updateTime: string
}

export interface qrcode {
    code:string,
    qrcode:string
}

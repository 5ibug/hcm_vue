import request from '../../utils/request'
import {userInfo} from "../../type/index/userInfo";

const api = {
    getUserInfo: 'hcm/me',
}

export function getUserInfo(): Promise<userInfo> {
    return request.get(api.getUserInfo)
}

